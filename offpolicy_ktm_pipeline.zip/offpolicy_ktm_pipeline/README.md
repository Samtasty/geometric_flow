# Off-Policy KTM Pipeline

This folder provides a clean end-to-end structure for:

1. PIX dataframe preprocessing and KTM feature construction
2. Gaussian regression by order
3. Propensity computation and off-policy tuple creation
4. Off-policy estimators + policy training
5. End-to-end notebook with visualizations

## Structure

- `src/dataframe_processing.py`
  - `process_pix_dataset(...)`
  - `build_ktm_dataframe(...)`
- `src/gaussian_regression.py`
  - `fit_gaussian_regression(...)`
  - `fit_gaussian_by_order(...)`
- `src/propensity.py`
  - `attach_behavior_params(...)`
  - `compute_propensity_and_reward(...)`
  - `build_offpolicy_dataset(...)`
- `src/estimators_and_training.py`
  - `train_global_policy(...)`
  - estimators: IPS, SNIPS, CIPS, CSNIPS
  - `compute_log_mixture_propensity(...)`
  - `mc_policy_value(...)`, `optimal_irt_value(...)`
- `src/utils.py`
  - `set_global_seed(...)`
  - `get_default_device(...)`
  - `ensure_parent_dir(...)`
- `src/visualization.py`
  - training curves + policy curve plotting helpers
- `notebooks/end_to_end_offpolicy_pipeline.ipynb`
  - runnable notebook from raw/processed data to plots

## Dependencies

Install from:

- `offpolicy_ktm_pipeline/requirements.txt`

Main libraries used:

- `numpy`
- `pandas`
- `scipy`
- `scikit-learn`
- `matplotlib`
- `torch`
- `tqdm`
- `Pillow`
- `jupyter`
- `ipykernel`

## Run

Open:

- `offpolicy_ktm_pipeline/notebooks/end_to_end_offpolicy_pipeline.ipynb`

The notebook imports from `offpolicy_ktm_pipeline/src` and runs the full workflow.
