from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd
from scipy.optimize import minimize


@dataclass
class GaussianRegressionFit:
    beta_mu: np.ndarray
    beta_sigma: np.ndarray
    nll: float
    rmse: float
    mae: float
    success: bool
    message: str


def poly_design(x: np.ndarray, degree: int) -> np.ndarray:
    cols = [np.ones_like(x)]
    for d in range(1, degree + 1):
        cols.append(x ** d)
    return np.column_stack(cols)


def poly_eval(x: np.ndarray, coeffs: np.ndarray) -> np.ndarray:
    y = np.zeros_like(x, dtype=float)
    for d, c in enumerate(coeffs):
        y += c * (x ** d)
    return y


def fit_gaussian_regression(
    theta: np.ndarray,
    delta: np.ndarray,
    *,
    mu_degree: int = 1,
    sigma_degree: int = 2,
    sigma_floor: float = 1e-4,
) -> GaussianRegressionFit:
    """
    Fit delta | theta ~ N(mu(theta), sigma(theta)^2) with polynomial mu/log-sigma.
    """
    x_mu = poly_design(theta, mu_degree)
    x_sig = poly_design(theta, sigma_degree)
    k_mu = x_mu.shape[1]
    cst = 0.5 * np.log(2.0 * np.pi)

    beta_mu0 = np.linalg.lstsq(x_mu, delta, rcond=None)[0]
    resid = delta - x_mu @ beta_mu0
    beta_sig0 = np.zeros(x_sig.shape[1], dtype=float)
    beta_sig0[0] = float(np.log(np.std(resid) + 1e-3))
    p0 = np.concatenate([beta_mu0, beta_sig0])

    def nll(params: np.ndarray) -> float:
        b_mu = params[:k_mu]
        b_sig = params[k_mu:]
        mu = x_mu @ b_mu
        sigma = np.maximum(np.exp(x_sig @ b_sig), sigma_floor)
        z = (delta - mu) / sigma
        return float(np.mean(cst + np.log(sigma) + 0.5 * (z ** 2)))

    out = minimize(nll, p0, method="L-BFGS-B")
    p = out.x if out.success else p0
    beta_mu = p[:k_mu]
    beta_sigma = p[k_mu:]
    mu_hat = x_mu @ beta_mu
    rmse = float(np.sqrt(np.mean((delta - mu_hat) ** 2)))
    mae = float(np.mean(np.abs(delta - mu_hat)))

    return GaussianRegressionFit(
        beta_mu=beta_mu,
        beta_sigma=beta_sigma,
        nll=float(nll(p)),
        rmse=rmse,
        mae=mae,
        success=bool(out.success),
        message=str(out.message),
    )


def fit_gaussian_by_order(
    df_ktm: pd.DataFrame,
    *,
    order_col: str = "order_sequence",
    theta_col: str = "proficiency",
    delta_col: str = "difficulties",
    mu_degree: int = 1,
    sigma_degree: int = 2,
    sigma_floor: float = 1e-4,
    min_obs_per_order: int = 200,
) -> pd.DataFrame:
    """
    Fit one Gaussian regression model per order_sequence.
    """
    rows: list[dict[str, object]] = []
    for order_val, g in df_ktm.groupby(order_col, sort=True):
        if len(g) < min_obs_per_order:
            continue
        theta = g[theta_col].to_numpy(dtype=float)
        delta = g[delta_col].to_numpy(dtype=float)
        fit = fit_gaussian_regression(
            theta,
            delta,
            mu_degree=mu_degree,
            sigma_degree=sigma_degree,
            sigma_floor=sigma_floor,
        )
        rec: dict[str, object] = {
            "subset": f"order_{int(order_val)}",
            "order_sequence": int(order_val),
            "order_min": int(order_val),
            "order_max": int(order_val),
            "n_obs": int(len(g)),
            "mu_degree": int(mu_degree),
            "sigma_degree": int(sigma_degree),
            "nll": fit.nll,
            "rmse": fit.rmse,
            "mae": fit.mae,
            "success": fit.success,
            "message": fit.message,
        }
        for d, val in enumerate(fit.beta_mu):
            rec[f"beta_mu_{d}"] = float(val)
        for d, val in enumerate(fit.beta_sigma):
            rec[f"beta_sigma_{d}"] = float(val)
        rows.append(rec)

    out = pd.DataFrame(rows)
    if not out.empty:
        out = out.sort_values("order_sequence").reset_index(drop=True)
    return out

