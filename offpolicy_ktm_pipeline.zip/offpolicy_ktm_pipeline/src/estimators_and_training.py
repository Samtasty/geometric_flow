from __future__ import annotations

from typing import Iterable

import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader, TensorDataset

from models.offpolicy_gaussian_policy import GlobalGaussianPolicy
from .utils import get_default_device, set_global_seed


def poly_eval(x: np.ndarray, coeffs: np.ndarray) -> np.ndarray:
    y = np.zeros_like(x, dtype=float)
    for d, c in enumerate(coeffs):
        y += c * (x ** d)
    return y


def _log_gaussian_pdf(delta: np.ndarray, mu: np.ndarray, sigma: np.ndarray) -> np.ndarray:
    z = (delta - mu) / sigma
    return -0.5 * np.log(2.0 * np.pi) - np.log(sigma) - 0.5 * (z ** 2)


def _extract_degree(cols: Iterable[str], prefix: str) -> int:
    idx = [int(c.split("_")[-1]) for c in cols if c.startswith(prefix)]
    if not idx:
        raise ValueError(f"Missing {prefix}* columns")
    return max(idx)


def _build_behavior_lookup(
    fit_df: pd.DataFrame,
    *,
    mu_degree: int,
    sigma_degree: int,
) -> dict[int, tuple[np.ndarray, np.ndarray]]:
    fit = fit_df.copy()
    if "order_sequence" not in fit.columns:
        if "order_min" in fit.columns and "order_max" in fit.columns:
            fit = fit[fit["order_min"] == fit["order_max"]].copy()
            fit["order_sequence"] = fit["order_min"].astype(int)
        else:
            raise ValueError("fit_df must contain order_sequence or order_min/order_max")
    out: dict[int, tuple[np.ndarray, np.ndarray]] = {}
    for _, row in fit.iterrows():
        order_val = int(row["order_sequence"])
        b_mu = np.array([float(row.get(f"beta_mu_{d}", 0.0)) for d in range(mu_degree + 1)], dtype=float)
        b_sig = np.array([float(row.get(f"beta_sigma_{d}", 0.0)) for d in range(sigma_degree + 1)], dtype=float)
        out[order_val] = (b_mu, b_sig)
    return out


def compute_log_mixture_propensity(
    *,
    theta: np.ndarray,
    delta: np.ndarray,
    orders: np.ndarray,
    fit_df: pd.DataFrame,
    mu_degree: int,
    sigma_degree: int,
    sigma_floor: float,
) -> np.ndarray:
    """
    log p_mix(delta|theta) where p_mix = sum_m rho_m p_m and rho_m are order frequencies.
    """
    lookup = _build_behavior_lookup(fit_df, mu_degree=mu_degree, sigma_degree=sigma_degree)
    comp_counts = pd.Series(orders).value_counts().sort_index()
    comp_orders = comp_counts.index.to_numpy(dtype=int)
    comp_weights = comp_counts.to_numpy(dtype=float)
    comp_weights = comp_weights / float(comp_weights.sum())

    log_mix = np.full(theta.shape[0], -np.inf, dtype=float)
    for order_val, rho in zip(comp_orders, comp_weights):
        if int(order_val) not in lookup:
            continue
        b_mu, b_sig = lookup[int(order_val)]
        mu = poly_eval(theta, b_mu)
        sigma = np.maximum(np.exp(poly_eval(theta, b_sig)), sigma_floor)
        log_p = _log_gaussian_pdf(delta=delta, mu=mu, sigma=sigma)
        log_mix = np.logaddexp(log_mix, np.log(float(rho)) + log_p)
    return log_mix.astype(np.float32)


@torch.no_grad()
def _evaluate_estimators(
    policy: GlobalGaussianPolicy,
    theta: torch.Tensor,
    delta: torch.Tensor,
    reward: torch.Tensor,
    log_prop_b: torch.Tensor,
    *,
    max_weight: float,
    clip_c: float,
    device: torch.device,
) -> dict[str, float]:
    policy.eval()
    th = theta.to(device)
    de = delta.to(device)
    rw = reward.to(device)
    lb = log_prop_b.to(device)

    log_p_new = policy.log_prob(delta=de, theta=th)
    log_ratio = torch.clamp(log_p_new - lb, min=-20.0, max=float(np.log(max_weight)))
    w = torch.exp(log_ratio)
    w_clip = torch.clamp(w, max=float(clip_c))

    ips = torch.mean(w * rw)
    snips = torch.sum(w * rw) / torch.sum(w).clamp_min(1e-12)
    cips = torch.mean(w_clip * rw)
    csnips = torch.sum(w_clip * rw) / torch.sum(w_clip).clamp_min(1e-12)
    ess = (torch.sum(w) ** 2) / torch.sum(w ** 2).clamp_min(1e-12)
    ess_clip = (torch.sum(w_clip) ** 2) / torch.sum(w_clip ** 2).clamp_min(1e-12)
    return {
        "ips": float(ips.item()),
        "snips": float(snips.item()),
        "cips": float(cips.item()),
        "csnips": float(csnips.item()),
        "ess": float(ess.item()),
        "ess_clip": float(ess_clip.item()),
        "mean_w": float(torch.mean(w).item()),
        "std_w": float(torch.std(w).item()),
    }


def get_policy_coefficients(policy: GlobalGaussianPolicy) -> tuple[np.ndarray, np.ndarray]:
    with torch.no_grad():
        b_mu = policy.beta_mu.detach().cpu().numpy().astype(float).copy()
        b_sig = policy.beta_sigma.detach().cpu().numpy().astype(float).copy()
    return b_mu, b_sig


def train_global_policy(
    df: pd.DataFrame,
    *,
    fit_df: pd.DataFrame | None = None,
    objective: str = "snips",
    denominator: str = "logged",
    theta_col: str = "proficiency",
    delta_col: str = "difficulties",
    reward_col: str = "reward",
    order_col: str = "order_sequence",
    log_prop_col: str = "log_propensity",
    mu_degree: int = 1,
    sigma_degree: int = 2,
    sigma_floor: float = 1e-4,
    max_weight: float = 20.0,
    clip_c: float = 10.0,
    epochs: int = 5,
    batch_size: int = 8192,
    lr: float = 0.005,
    l2_coef: float = 1e-6,
    num_workers: int = 0,
    seed: int = 42,
    init_from_first_behavior: bool = True,
    device: str | None = None,
) -> tuple[GlobalGaussianPolicy, pd.DataFrame, dict[str, np.ndarray]]:
    """
    Train a single global Gaussian policy with IPS/SNIPS/CIPS/CSNIPS objective.
    """
    if objective not in {"ips", "snips", "cips", "csnips"}:
        raise ValueError(f"Unsupported objective: {objective}")
    if denominator not in {"logged", "mixture"}:
        raise ValueError(f"Unsupported denominator: {denominator}")

    set_global_seed(seed)

    work = df[[theta_col, delta_col, reward_col, order_col, log_prop_col]].dropna().copy()
    theta_np = work[theta_col].to_numpy(dtype=np.float32)
    delta_np = work[delta_col].to_numpy(dtype=np.float32)
    reward_np = work[reward_col].to_numpy(dtype=np.float32)

    if denominator == "mixture":
        if fit_df is None:
            raise ValueError("fit_df is required for denominator='mixture'")
        log_prop_b_np = compute_log_mixture_propensity(
            theta=theta_np.astype(float),
            delta=delta_np.astype(float),
            orders=work[order_col].to_numpy(dtype=int),
            fit_df=fit_df,
            mu_degree=mu_degree,
            sigma_degree=sigma_degree,
            sigma_floor=sigma_floor,
        )
    else:
        log_prop_b_np = work[log_prop_col].to_numpy(dtype=np.float32)

    theta = torch.from_numpy(theta_np)
    delta = torch.from_numpy(delta_np)
    reward = torch.from_numpy(reward_np)
    log_prop_b = torch.from_numpy(log_prop_b_np.astype(np.float32))

    dataset = TensorDataset(theta, delta, reward, log_prop_b)
    loader = DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=True,
        num_workers=num_workers,
        pin_memory=torch.cuda.is_available(),
        drop_last=False,
    )

    target_device = get_default_device(device)
    policy = GlobalGaussianPolicy(mu_degree=mu_degree, sigma_degree=sigma_degree, sigma_floor=sigma_floor).to(
        target_device
    )
    if init_from_first_behavior and fit_df is not None and len(fit_df) > 0:
        fit = fit_df.copy()
        if "order_sequence" not in fit.columns and "order_min" in fit.columns and "order_max" in fit.columns:
            fit = fit[fit["order_min"] == fit["order_max"]].copy()
            fit["order_sequence"] = fit["order_min"].astype(int)
        if "order_sequence" in fit.columns and not fit.empty:
            first_row = fit.sort_values("order_sequence").iloc[0]
            policy.init_from_behavior_row(first_row)

    optimizer = torch.optim.Adam(policy.parameters(), lr=lr)
    history: list[dict[str, float]] = []
    init_metrics = _evaluate_estimators(
        policy,
        theta=theta,
        delta=delta,
        reward=reward,
        log_prop_b=log_prop_b,
        max_weight=max_weight,
        clip_c=clip_c,
        device=target_device,
    )
    history.append({"epoch": 0, "train_loss": np.nan, "objective": objective, "denominator": denominator, **init_metrics})

    for epoch in range(1, epochs + 1):
        policy.train()
        running = 0.0
        n_seen = 0
        for b_theta, b_delta, b_reward, b_logb in loader:
            b_theta = b_theta.to(target_device)
            b_delta = b_delta.to(target_device)
            b_reward = b_reward.to(target_device)
            b_logb = b_logb.to(target_device)

            optimizer.zero_grad(set_to_none=True)
            log_p_new = policy.log_prob(delta=b_delta, theta=b_theta)
            log_ratio = torch.clamp(log_p_new - b_logb, min=-20.0, max=float(np.log(max_weight)))
            w = torch.exp(log_ratio)
            w_clip = torch.clamp(w, max=float(clip_c))

            ips_obj = torch.mean(w * b_reward)
            snips_obj = torch.sum(w * b_reward) / torch.sum(w).clamp_min(1e-12)
            cips_obj = torch.mean(w_clip * b_reward)
            csnips_obj = torch.sum(w_clip * b_reward) / torch.sum(w_clip).clamp_min(1e-12)

            if objective == "ips":
                obj = ips_obj
            elif objective == "snips":
                obj = snips_obj
            elif objective == "cips":
                obj = cips_obj
            else:
                obj = csnips_obj

            reg = l2_coef * (torch.mean(policy.beta_mu ** 2) + torch.mean(policy.beta_sigma ** 2))
            loss = -obj + reg
            loss.backward()
            optimizer.step()

            bs = b_theta.shape[0]
            running += float(loss.item()) * bs
            n_seen += bs

        metrics = _evaluate_estimators(
            policy,
            theta=theta,
            delta=delta,
            reward=reward,
            log_prop_b=log_prop_b,
            max_weight=max_weight,
            clip_c=clip_c,
            device=target_device,
        )
        history.append(
            {
                "epoch": epoch,
                "train_loss": running / max(1, n_seen),
                "objective": objective,
                "denominator": denominator,
                **metrics,
            }
        )

    b_mu, b_sig = get_policy_coefficients(policy)
    coeffs = {"beta_mu": b_mu, "beta_sigma": b_sig}
    return policy, pd.DataFrame(history), coeffs


def mc_policy_value(
    *,
    theta: np.ndarray,
    beta_mu: np.ndarray,
    beta_sigma: np.ndarray,
    delta_min: float,
    sigma_floor: float = 1e-4,
    n_mc: int = 512,
    seed: int = 42,
) -> float:
    """
    Monte-Carlo estimate of E[r] for r = sigmoid(theta - delta) * (delta - delta_min), delta ~ policy.
    """
    mu = poly_eval(theta, beta_mu)
    sigma = np.maximum(np.exp(poly_eval(theta, beta_sigma)), sigma_floor)
    rng = np.random.default_rng(seed)
    eps = rng.standard_normal(size=(n_mc, 1))
    delta = mu[None, :] + sigma[None, :] * eps
    prob = 1.0 / (1.0 + np.exp(-(theta[None, :] - delta)))
    reward = prob * (delta - delta_min)
    return float(np.mean(reward))


def optimal_irt_value(
    *,
    theta: np.ndarray,
    delta_min: float,
    delta_max: float,
    n_delta_grid: int = 1200,
) -> float:
    d_grid = np.linspace(delta_min, delta_max, n_delta_grid)
    z = theta[:, None] - d_grid[None, :]
    p = 1.0 / (1.0 + np.exp(-z))
    exp_reward = p * (d_grid[None, :] - delta_min)
    best = np.max(exp_reward, axis=1)
    return float(np.mean(best))
