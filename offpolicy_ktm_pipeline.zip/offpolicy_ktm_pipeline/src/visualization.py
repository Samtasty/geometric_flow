from __future__ import annotations

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from .gaussian_regression import poly_eval


def plot_training_history(
    history_df: pd.DataFrame,
    *,
    metrics: tuple[str, ...] = ("ips", "snips", "cips", "csnips"),
    title: str = "Off-Policy Training Metrics",
) -> tuple[plt.Figure, plt.Axes]:
    fig, ax = plt.subplots(figsize=(8.5, 4.8))
    x = history_df["epoch"].to_numpy(dtype=int)
    for m in metrics:
        if m in history_df.columns:
            ax.plot(x, history_df[m], linewidth=2.0, label=m)
    ax.set_xlabel("epoch")
    ax.set_ylabel("value")
    ax.set_title(title)
    ax.grid(alpha=0.25)
    ax.legend(loc="best")
    fig.tight_layout()
    return fig, ax


def plot_policy_curves(
    *,
    theta_grid: np.ndarray,
    behavior_mu: np.ndarray,
    behavior_sigma: np.ndarray,
    learned_mu: np.ndarray,
    learned_sigma: np.ndarray,
    optimal_delta: np.ndarray | None = None,
    y_min: float = -4.0,
    y_max: float = 4.0,
    title: str = "Behavior vs Learned Policy",
) -> tuple[plt.Figure, plt.Axes]:
    fig, ax = plt.subplots(figsize=(9.0, 5.2))

    ax.plot(theta_grid, behavior_mu, color="#ff7f0e", lw=2.0, label="behavior mean")
    ax.fill_between(
        theta_grid,
        behavior_mu - behavior_sigma,
        behavior_mu + behavior_sigma,
        color="#ff7f0e",
        alpha=0.16,
        label="behavior +/- sigma",
    )

    ax.plot(theta_grid, learned_mu, color="#1f77b4", lw=2.2, label="learned mean")
    ax.fill_between(
        theta_grid,
        learned_mu - learned_sigma,
        learned_mu + learned_sigma,
        color="#1f77b4",
        alpha=0.16,
        label="learned +/- sigma",
    )

    if optimal_delta is not None:
        ax.plot(theta_grid, optimal_delta, color="#2ca02c", lw=2.2, linestyle="--", label="optimal (IRT)")

    ax.set_xlabel("theta")
    ax.set_ylabel("delta")
    ax.set_ylim(y_min, y_max)
    ax.set_title(title)
    ax.grid(alpha=0.25)
    ax.legend(loc="best")
    fig.tight_layout()
    return fig, ax


def build_policy_curves(
    *,
    theta_grid: np.ndarray,
    beta_mu_behavior: np.ndarray,
    beta_sigma_behavior: np.ndarray,
    beta_mu_learned: np.ndarray,
    beta_sigma_learned: np.ndarray,
    sigma_floor: float = 1e-4,
) -> dict[str, np.ndarray]:
    b_mu = poly_eval(theta_grid, beta_mu_behavior)
    b_sigma = np.maximum(np.exp(poly_eval(theta_grid, beta_sigma_behavior)), sigma_floor)
    l_mu = poly_eval(theta_grid, beta_mu_learned)
    l_sigma = np.maximum(np.exp(poly_eval(theta_grid, beta_sigma_learned)), sigma_floor)
    return {
        "behavior_mu": b_mu,
        "behavior_sigma": b_sigma,
        "learned_mu": l_mu,
        "learned_sigma": l_sigma,
    }

